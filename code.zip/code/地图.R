# 加载必要的包
library(readxl)      
library(dplyr)       
library(stringr)     
library(usmap)       
library(ggplot2)     

# 文件路径（请根据实际情况修改）
file_path <- "C:/Users/kuo/Desktop/vaers/6.VARICELLA/报告地区.xlsx"

# 读取数据
df <- read_excel(file_path)

# 重命名列
colnames(df) <- c("state", "value_str")

# 保留标准美国州（含 DC），过滤掉 "Missing" 及非美属地
valid_states <- c(state.abb, "DC")   
df <- df %>%
  filter(state %in% valid_states)    

# 提取纯数字
df <- df %>%
  mutate(count = as.numeric(str_extract(value_str, "^[0-9]+")))

# 绘制地图（蓝色渐变，无副标题和脚注）
p <- plot_usmap(data = df, values = "count", regions = "states") +
  scale_fill_distiller(
    palette = "Blues", 
    direction = 1, 
    name = "Number of Reports",
    na.value = "grey90",
    breaks = pretty(df$count)
  ) +
    theme(
    legend.position = "right",
    legend.title = element_text(size = 11, face = "plain"),
    legend.text = element_text(size = 9),
    legend.key.width = unit(0.8, "cm"),
    panel.background = element_blank()
  )

# 显示图形
print(p)

# 如需保存高清图片，请取消注释
ggsave("report_map.tif", plot = p, width = 10, height = 8, dpi = 600, bg = "white")


