# Load required packages
library(readxl)
library(ggplot2)
library(dplyr)
library(ggrepel)

# 1. Read data from your specified path
file_path <- "C:/Users/kuo/Desktop/vaers/6.VARICELLA/年度上报频数统计.xlsx"
df <- read_excel(file_path, sheet = "Sheet 1")

# 2. Find peak year for annotation
peak_row <- df[which.max(df$n), ]
peak_year <- peak_row$GETDATAYEAR
peak_value <- peak_row$n

# 3. Create the plot
p <- ggplot(df, aes(x = GETDATAYEAR, y = n)) +
  # Area fill (semi-transparent) under the line
  geom_area(fill = "#3B82F6", alpha = 0.15) +
  
  # Main line
  geom_line(color = "#3B82F6", size = 1.4) +
  
  # Points (hollow with border)
  geom_point(color = "#F59E0B", fill = "white", size = 3.5, shape = 21, stroke = 1.2) +
  
  # Numeric labels with white background
  geom_label_repel(
    aes(label = n),
    size = 3.2,
    color = "#1E293B",
    fill = "white",
    alpha = 0.85,
    label.size = 0,
    box.padding = 0.5,
    point.padding = 0.4,
    segment.color = "#94A3B8",
    segment.size = 0.3,
    min.segment.length = 0,
    max.overlaps = Inf,
    force = 2.5
  ) +
  
  # Annotate the peak point
  annotate(
    "label",
    x = peak_year,
    y = peak_value + 150,
    label = paste0("Peak: ", peak_value),
    color = "#DC2626",
    fill = "white",
    alpha = 0.9,
    label.size = 0,
    fontface = "bold",
    size = 4
  ) +
  
  # Axis breaks
  scale_x_continuous(
    breaks = seq(1995, 2025, by = 5),
    limits = c(1993, 2027)
  ) +
  scale_y_continuous(
    expand = expansion(mult = c(0.05, 0.15)),
    breaks = seq(0, 4500, by = 1000)
  ) +
  
  # Labels
  labs(
    x = "Year",
    y = "Number of Reports (n)"
  ) +
  
  # Refined theme
  theme_minimal(base_family = "sans") +
  theme(
    # Title: centered
    plot.title = element_text(
      size = 20, face = "bold", color = "#0F172A",
      hjust = 0.5,                        # Centered
      margin = margin(b = 10)
    ),
    # X-axis label: increased distance from axis
    axis.title.x = element_text(
      size = 14, face = "plain", color = "#334155",
      margin = margin(t = 12)             # extra top margin
    ),
    # Y-axis label: increased distance from axis
    axis.title.y = element_text(
      size = 14, face = "plain", color = "#334155",
      margin = margin(r = 12)             # extra right margin
    ),
    axis.text = element_text(size = 12, color = "#475569"),
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "#E2E8F0", size = 0.5),
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    axis.line = element_line(color = "#CBD5E1", size = 0.5),
    axis.ticks = element_line(color = "#CBD5E1"),
    plot.margin = margin(25, 30, 25, 30)
  )

# 4. Display
print(p)

# 5. Save high-res PNG
ggsave("curve graph.tif", plot = p, width = 10, height = 8, dpi = 600, bg = "white")