library(tidyverse)
library(readxl)
library(forestploter)
library(grid)

# 从指定的 Excel 文件 '不良反应信号(pt).xlsx' 中读取数据
# 替换成自己的路径
d <- read_xlsx("C:/Users/kuo/Desktop/vaers/6.VARICELLA/0000不良反应信号(PT).xlsx")


# 创建一个名为 ' '（空格）的列，该列包含 100 个空格组成的字符串，用于布局
d$` ` <- paste(rep(" ", 100), collapse = " ")

# 设置森林图的主题样式
# 以下是具体的样式设置参数
tm <- forest_theme(
  base_size = 8,   # 设置基础字体大小为 8
  ci_pch = 15,  # 设置置信区间点的形状为 15（实心正方形）
  ci_col = "#2F4F96",   # 设置置信区间点的颜色为指定的十六进制颜色
  ci_lty = 1,     # 设置置信区间线的线型为实线
  ci_lwd = 1.5,   # 设置置信区间线的宽度为 1.5 
  ci_Theight = 0.2,   # 设置置信区间顶部线条的高度
  
  # 参考线相关设置
  refline_lwd = 1.5,  # 设置参考线的宽度为 1.5
  refline_lty = "dashed",  # 设置参考线的线型为虚线
  refline_col = "red",  # 设置参考线的颜色为红色
  
  # 脚注相关设置
  footnote_cex = 1.1,  # 设置脚注的字体缩放比例为 1.1
  footnote_fontface = "italic",  # 设置脚注的字体样式为斜体
  footnote_col = "blue"  # 设置脚注的颜色为蓝色
  )

# 从 d 数据框中选取第13列、1列、 2 列、 20 列、6列、7列、8列的数据，组成新的数据框 dt，用于绘图
dt <- d[, c(18, 1,  2, 20, 28, 6, 7, 8)]

#以pt的a值进行排序
dt <- dt %>%
  arrange(-a) 
#取前50
dt <- dt[1:20, ]

# 定义一个边界值 5，用于限制置信区间的显示范围
rightmost <- 5
# 复制 RORU（置信区间上限）列的数据到 uu 和 uug 向量中
uug <- uu <- dt$RORU
# 复制 RORL（置信区间下限）列的数据到 ll 和 llg 向量中
llg <- ll <- dt$RORL

# 将置信区间上限中大于等于 rightmost 的值调整为 rightmost * 1.001
uug[uu >= rightmost] <- rightmost * 1.001
# 将置信区间下限中大于等于 rightmost 的值调整为 rightmost * 0.999
llg[ll >= rightmost] <- rightmost * 0.999

colnames(dt)[1] <- "SOC"


# 使用 forest 函数绘制森林图，并将结果存储在 p 对象中
p <- forest(  dt[,1:5],  # 用于绘图的数据
              est = dt$ROR,
              lower = llg,  # 指定调整后的置信区间下限向量
              upper = uug,  # 指定调整后的置信区间上限向量
              sizes = 0.6,  # 设置点和线的大小为 0.6
              ci_column = 5,  # 指定森林图的置信区间在第 4 列显示
              ref_line = 1,  # 设置参考线的位置为 1
              xlim = c(0, rightmost),  # 设置 x 轴的显示范围为 0 到 rightmost
              theme = tm  # 应用之前定义的森林图主题 tm
              )

# 创建一个箭头对象 arr
arr <- segmentsGrob(
  x0 = unit(1, 'npc') - unit(1, 'mm'),  # 箭头起点的 x 坐标
  x1 = 1,  # 箭头终点的 x 坐标
  y0 = 0.5,  # 箭头起点的 y 坐标
  y1 = 0.5,  # 箭头终点的 y 坐标
  gp = gpar(fill = '#2F4F96', col = 'transparent'),  # 设置箭头的填充颜色和边框颜色
  arrow = arrow(length = unit(0.15, "inches"), ends = "last", type = "closed")  # 设置箭头的长度、结束方向和类型
  )

# 加载 gtable 包，用于处理表格布局
library(gtable)

# 判断 p$grobs 中的每个元素是否为 'makeci' 类型，并将结果存储在 pan 向量中
sapply(p$grobs, function(x) {
  inherits(x, 'makeci')
}) -> pan

# 找出 pan 向量中为 TRUE 的元素的索引，并存储在 modi 向量中
which(pan) -> modi

# 将 p 的布局信息存储在 la 中
p$layout -> la

# 循环处理每个符合条件的元素
for (ii in 1:length(modi)) {
  ind <- modi[[ii]]  # 获取当前元素的索引
  
  # 如果第 ii 个置信区间下限大于 rightmost，则将对应的图形元素替换为空对象
  if (ll[[ii]] > rightmost) p$grobs[[ind]] <- nullGrob()
  # 如果第 ii 个置信区间上限大于 rightmost，则在相应位置添加箭头
  if (uu[[ii]] > rightmost) {
    p <- gtable_add_grob(
      p,
      grobs = arr,
      t = la[ind, 't'],  # 箭头的顶部位置
      l = la[ind, 'l'],  # 箭头的左侧位置
      b = la[ind, 'b'],  # 箭头的底部位置
      r = la[ind, 'r']  # 箭头的右侧位置
    )
  }
}


# 获取森林图 p 的宽度和高度
p_wh <- get_wh(plot = p)

# 打开一个 PDF 文件设备，设置文件名为 'forest.pdf'，并根据森林图的宽度和高度设置 PDF 文件的尺寸
cairo_pdf("forest.pdf", width = p_wh[1], height = p_wh[2])

# 将森林图 p 绘制到 PDF 文件中
plot(p)

# 关闭 PDF 文件设备，完成文件保存
dev.off()

