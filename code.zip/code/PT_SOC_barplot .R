# PT-SOC horizontal bar chart
# Required packages: readxl, dplyr, ggplot2, stringr
# install.packages(c("readxl", "dplyr", "ggplot2", "stringr"))

library(readxl)
library(dplyr)
library(ggplot2)
library(stringr)

# 1. Read data (keep this script in the same folder as 0单独.xlsx,
#    or replace the filename with the full path to your Excel file)
dat <- read_excel("C:/Users/kuo/Desktop/0联合.xlsx")

# 2. Format PT: first letter uppercase, all remaining letters lowercase
#    Sort from the largest N at the top to the smallest at the bottom.
dat <- dat %>%
  mutate(
    PT = str_to_sentence(as.character(PT)),
    SOC = as.character(SOC),
    N = as.numeric(N)
  ) %>%
  filter(!is.na(PT), !is.na(SOC), !is.na(N)) %>%
  arrange(N) %>%
  mutate(PT = factor(PT, levels = unique(PT)))

# 3. Set one consistent color for each SOC
soc_levels <- unique(dat$SOC)
soc_colors <- c(
  "Infections and infestations" = "#7DBBD3",
  "Skin and subcutaneous tissue disorders" = "#F08072",
  "Injury, poisoning and procedural complications" = "#2F78A8",
  "General disorders and administration site conditions" = "#D8D99B"
)

# Add colors automatically if the input contains other SOC categories
missing_soc <- setdiff(soc_levels, names(soc_colors))
if (length(missing_soc) > 0) {
  extra_cols <- grDevices::hcl.colors(length(missing_soc), palette = "Set 2")
  names(extra_cols) <- missing_soc
  soc_colors <- c(soc_colors, extra_cols)
}

# 4. Plot
p <- ggplot(dat, aes(x = N, y = PT, fill = SOC)) +
  geom_col(width = 0.72, color = NA) +
  geom_text(aes(label = N), hjust = -0.18, size = 3,
            family = "Arial", color = "black") +
  scale_fill_manual(values = soc_colors, breaks = soc_levels, name = "SOC") +
  scale_x_continuous(
    name = "Case number (N)",
    # A small left expansion creates visible space between the bars and Y axis
    expand = expansion(mult = c(0.015, 0.03)),
    limits = c(0, max(dat$N, na.rm = TRUE) * 1.65)
  ) +
  labs(y = NULL) +
  theme_classic(base_size = 10, base_family = "Arial") +
  theme(
    # Keep both axes visible, including the vertical Y axis line
    axis.line.x = element_line(color = "black", linewidth = 0.45),
    axis.line.y = element_line(color = "black", linewidth = 0.45),
    axis.ticks.y = element_blank(),
    axis.text.y = element_text(color = "black", size = 8, margin = margin(r = 5)),
    axis.text.x = element_text(color = "black", size = 8),
    axis.title.x = element_text(color = "black", size = 9, margin = margin(t = 5)),
    
    # Legend inside the plotting panel, centered vertically
    legend.position = c(0.76, 0.50),
    legend.justification = c(0.5, 0.5),
    legend.background = element_rect(fill = "white", color = NA),
    legend.title = element_text(size = 9, face = "plain", margin = margin(b = 3)),
    # Vertically center SOC labels against their square color keys
    legend.text = element_text(size = 7, vjust = 0.5, margin = margin(l = 2)),
    legend.key = element_rect(fill = "white", color = NA),
    legend.key.width = grid::unit(0.34, "cm"),
    legend.key.height = grid::unit(0.34, "cm"),
    legend.spacing.y = grid::unit(0.08, "cm"),
    legend.margin = margin(2, 2, 2, 2)
  ) +
  guides(fill = guide_legend(
    ncol = 1,
    byrow = TRUE,
    keywidth = grid::unit(0.34, "cm"),
    keyheight = grid::unit(0.34, "cm"),
    label.position = "right",
    label.vjust = 0.5,
    override.aes = list(color = NA)
  ))

print(p)

ggsave(
  filename = "C:/Users/kuo/Desktop/PT_SOC_barplot联合.tiff",
  plot = p,
  device = "tiff",
  width = 10,
  height = 8,
  units = "in",
  dpi = 600,
  compression = "lzw",
  bg = "white"
)

# 5. Export a high-resolution figure for a manuscript
# ggsave("PT_SOC_barplot.png", p, width = 10, height = 6.5,
#        units = "in", dpi = 600, bg = "white")
# If Times New Roman is not available on your computer, install/enable that font
# or replace "Times New Roman" with another installed serif font.
