library(easyVAERS)
easyVAERS::locate_VAERS("C:/Users/kuo/Desktop/vaers/6.VARICELLA")

library(data.table)
library(ggplot2)
library(readxl)
library(ggrepel)
library(readr)
library(dplyr)

setwd("C:/Users/kuo/Desktop/vaers/6.VARICELLA")

# 使用 read_xlsx 函数读取指定路径的 Excel 文件，并将数据存储在变量 d 中
d <- read_xlsx("C:/Users/kuo/Desktop/vaers/6.VARICELLA/00不良反应信号(soc)-fatal.xlsx")

# 将数据框 d 转换为 data.table 对象，以便使用 data.table 的高效操作
setDT(d)

# 对数据集中的 a、b、c、d 列逐行进行操作，计算卡方检验的 p 值
# apply 函数用于对数组或矩阵的某一维度应用指定的函数
# 这里对 d 数据集中的 a、b、c、d 列按行（1 表示行）进行操作
pvalues <- apply(d[, .(a, b, c, d)], 1, function(x) {
  # 将当前行的数据转换为 2 行的矩阵
  inter <- matrix(x, nrow = 2)
  # 对转换后的矩阵进行卡方检验，并提取检验的 p 值
  chisq.test(inter)$p.value
})

# 在数据集中添加一个新列 pvalue，将计算得到的 p 值存储进去
d[, pvalue := pvalues]

# 在数据集中添加一个新列 adjustedP，使用 FDR（错误发现率）方法对 p 值进行调整
d[, adjustedP := p.adjust(pvalue, method = 'fdr')]

# 在数据集中添加一个新列 log2ror，计算 ROR（报告比值比）的 log2 值
d[, log2ror := log2(ROR)]

# 在数据集中添加一个新列 direction，根据 log2ror 的正负情况确定方向
# sign 函数返回数值的符号（-1 表示负数，0 表示零，1 表示正数），并将结果转换为字符类型
d[, direction := as.character(sign(log2ror))]

data <- d

# 在 data 数据集中添加一个新列 logpadj，计算调整后 p 值的负对数（以 10 为底）
data$logpadj <- -log10(data$adjustedP)

# 使用 dplyr 包的 rename 函数将 data 数据集中的列 a 重命名为 case
data <- data %>% rename(case = a)

# 使用 ggplot2 包创建一个火山图
# aes 函数用于指定绘图的美学映射，这里 x 轴为 log2ror，y 轴为 logpadj
pp <- ggplot(data, aes(x = log2ror, y = logpadj)) +
  # 添加散点图，每个点的颜色由 case 列的值决定，点的大小为 3
  geom_point(aes(color = case), size = 3) +
  # 添加文本标签，使用 ggrepel 包避免标签重叠，标签内容由 PT 列提供，颜色由 case 列决定
  # max.overlaps 参数限制最大重叠数，这里设置为 100
  geom_label_repel(aes(label = soc_name_en, color = case), max.overlaps = 100) +
  # 设置颜色渐变，从低到高分别为 "#45BDD8" 和 "#E24E3A"
  scale_color_gradient(low = "#45BDD8", high = "#E24E3A") +
  # 设置坐标轴标签和颜色条的标题
  labs(x = "log ROR", y = "-log(p-adjust)", color = "Number of Cases") +
  # 添加一条垂直虚线，x 轴截距为 0，线类型为 2，颜色为黑色，线宽为 0.8
  # 这条线通常作为 logFC（对数倍数变化）的分界线
  geom_vline(xintercept = 0, lty = 2, col = "black", lwd = 0.8) +
  # 添加一条水平虚线，y 轴截距为 -log10(0.05)，线类型为 2，颜色为黑色，线宽为 0.8
  # 这条线通常作为显著性阈值的分界线
  geom_hline(yintercept = -log10(0.05), lty = 2, col = "black", lwd = 0.8) +
  # 使用黑白主题，使图形更简洁美观
  theme_bw()

print(pp)

ggsave('火山图-fatal.tif', plot = pp, dpi = 600, width = 10, height = 8)






















