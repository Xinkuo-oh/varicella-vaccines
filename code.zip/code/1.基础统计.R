library(easyVAERS)
easyVAERS::locate_VAERS("C:/Users/kuo/Desktop/vaers/6.VARICELLA/数据")

###所有的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA")



###年龄1-2岁的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 2.99,
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/1. 1-2岁")


###年龄3-6岁的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 3,
                age_max = 6.99,
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/1. 3-6岁")


###年龄7-12岁的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 7,
                age_max = 12.99,
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/1. 7-12岁")



###male的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                sex = c("M"),
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/2. Male")


###female的###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                sex = c("F"),
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/2. Female")


###serious###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                serious = c("Y"),
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/3. Serious")


###non-serious###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                serious = c("N"),
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/3. non-Serious")


###died###
easyVAERS::AFUN(vaccine = c("VARICELLA (VARIVAX)",
                            "VARICELLA (VARILRIX)",
                            "VARICELLA (NO BRAND NAME)"),
                age_min = 1,
                age_max = 12.99,
                died = c("Y"),
                path = "C:/Users/kuo/Desktop/vaers/6.VARICELLA/4. Died")



